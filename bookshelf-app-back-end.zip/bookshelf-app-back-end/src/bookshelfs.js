/**** 
 * Memuat data notes yang disimpan dalam bentuk array objek. 
****/
const bookshelfs = [];

module.exports = bookshelfs;